using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class Relatorio
    {
        [Key]
        public int IdRelatorio { get; set; }

        [Required]
        public int Tipo { get; set; }

        [Required]
        public DateTime DataGeracao { get; set; }

        [Required, MaxLength(45)]
        public required string Conteudo { get; set; }

        [Required]
        public int IdFuncionario { get; set; }
    }
}
