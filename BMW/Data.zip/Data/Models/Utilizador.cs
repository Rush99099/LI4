using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class Utilizador
    {
        [Key]
        public int IdUtilizador { get; set; }

        [Required]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Nome { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;

        [Required]
        public bool IsCliente { get; set; }
    }
}
