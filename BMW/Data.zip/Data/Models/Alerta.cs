using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BMW.Data.Models
{
    public class Alerta
    {
        [Key]
        public int IdAlerta { get; set; }

        [Required]
        public int IdProgresso { get; set; }

        [Required]
        [MaxLength(45)]
        public string Mensagem { get; set; } = string.Empty;

        [Required]
        public DateTime Data { get; set; }
    }
}
