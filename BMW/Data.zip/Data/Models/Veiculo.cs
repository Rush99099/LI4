using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class Veiculo
    {
        [Key]
        public int IdVeiculo { get; set; }

        [Required, MaxLength(45)]
        public required string Modelo { get; set; }

        [Required]
        public int PrecoBase { get; set; }

        [Required]
        public DateTime DataAdicao { get; set; }
    }
}
