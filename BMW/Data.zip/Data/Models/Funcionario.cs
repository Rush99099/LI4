using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class Funcionario
    {
        [Key]
        public int IdFuncionario { get; set; }

        [Required]
        public DateTime ContractDate { get; set; }

        [Required]
        public int Posicao { get; set; }

        public int? Supervisor { get; set; }
    }
}
