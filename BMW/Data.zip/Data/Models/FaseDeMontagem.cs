using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class FaseDeMontagem
    {
        [Key]
        public int IdEstadoDeMontagem { get; set; }

        [Required]
        public int Ordem { get; set; }

        [Required, MaxLength(45)]
        public required string Descricao { get; set; }

        [Required]
        public DateTime TempoExecucaoExpectavel { get; set; }
    }
}
