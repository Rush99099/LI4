using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BMW.Data.Models
{
    public class Progresso
    {
        [Key, Column(Order = 0)]
        public int IdEncomenda { get; set; }

        [Key, Column(Order = 1)]
        public int IdFase { get; set; }

        [Required]
        public DateTime StartFase { get; set; }

        public DateTime? EndFase { get; set; }

        [Required]
        public int IdFuncionario { get; set; }
    }
}
