using System.ComponentModel.DataAnnotations;

namespace BMW.Data.Models
{
    public class Encomenda
    {
        [Key]
        public int IdEncomenda { get; set; }

        [Required]
        public DateTime DataRegisto { get; set; }

        [MaxLength(45)]
        public string? Observacoes { get; set; }

        [Required]
        public int IdCliente { get; set; }

        [Required]
        public int IdVeiculo { get; set; }

        [Required]
        public int Estado { get; set; }
    }
}
