using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using BMW.Data.Models;

namespace BMWAssemblyManager.Data
{
    public class UtilizadorDAO
    {
        private static UtilizadorDAO? singleton = null;
        private readonly string _connectionString;

        private UtilizadorDAO(string? connectionString)
        {
            _connectionString = connectionString 
                ?? throw new InvalidOperationException("A string de conexão não foi encontrada.");
        }

        public static UtilizadorDAO GetInstance(IConfiguration configuration)
        {
            if (singleton == null)
            {
                var connectionString = configuration.GetConnectionString("DefaultConnection");
                singleton = new UtilizadorDAO(connectionString);
            }
            return singleton;
        }

        public List<Utilizador> ObterTodos()
        {
            var utilizadores = new List<Utilizador>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Utilizador";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            utilizadores.Add(new Utilizador
                            {
                                IdUtilizador = reader.GetInt32(reader.GetOrdinal("idUtilizador")),
                                Email = reader.GetString(reader.GetOrdinal("email")),
                                Nome = reader.GetString(reader.GetOrdinal("nome")),
                                Password = reader.GetString(reader.GetOrdinal("password")),
                                IsCliente = reader.GetBoolean(reader.GetOrdinal("isCliente"))
                            });
                        }
                    }
                }
            }

            return utilizadores;
        }

        public bool ContainsKey(int key)
        {
            const string cmd = "SELECT 1 FROM Utilizador WHERE idUtilizador = @Key";
            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand(cmd, connection))
                {
                    command.Parameters.AddWithValue("@Key", key);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        return reader.HasRows;
                    }
                }
            }
        }

        public Utilizador? Get(int key)
        {
            Utilizador? utilizador = null;
            const string cmd = "SELECT * FROM Utilizador WHERE idUtilizador = @Key";
            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand(cmd, connection))
                {
                    command.Parameters.AddWithValue("@Key", key);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            utilizador = new Utilizador
                            {
                                IdUtilizador = reader.GetInt32(reader.GetOrdinal("idUtilizador")),
                                Nome = reader.GetString(reader.GetOrdinal("nome")),
                                Email = reader.GetString(reader.GetOrdinal("email")),
                                Password = reader.GetString(reader.GetOrdinal("password")),
                                IsCliente = reader.GetBoolean(reader.GetOrdinal("isCliente"))
                            };
                        }
                    }
                }
            }
            return utilizador;
        }

        public void Put(int key, Utilizador utilizador)
        {
            string cmd;
            if (ContainsKey(key))
            {
                cmd = "UPDATE Utilizador SET nome = @nome, email = @Email, password = @Password, isCliente = @IsCliente WHERE idUtilizador = @Key";
            }
            else
            {
                cmd = "INSERT INTO Utilizador (idUtilizador, nome, email, password, isCliente) VALUES (@Key, @Nome, @Email, @Password, @IsCliente)";
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand(cmd, connection))
                {
                    command.Parameters.AddWithValue("@Key", key);
                    command.Parameters.AddWithValue("@Nome", utilizador.Nome);
                    command.Parameters.AddWithValue("@Email", utilizador.Email);
                    command.Parameters.AddWithValue("@Password", utilizador.Password);
                    command.Parameters.AddWithValue("@IsCliente", utilizador.IsCliente);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public Utilizador? Remove(int key)
        {
            var utilizador = Get(key);
            if (utilizador != null)
            {
                const string cmd = "DELETE FROM Utilizador WHERE idUtilizador = @Key";
                using (var connection = new SqlConnection(_connectionString))
                {
                    using (var command = new SqlCommand(cmd, connection))
                    {
                        command.Parameters.AddWithValue("@Key", key);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
            return utilizador;
        }
    }
}
